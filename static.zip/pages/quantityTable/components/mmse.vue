<template>
	<view class="pages">
		TODO
	</view>
</template>

<script>
	export default {
		data() {
			return {}
		},
		mounted() {},
		methods: {}
	}
</script>

<style>

</style>